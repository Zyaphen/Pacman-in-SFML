﻿// Program.cs
// Activité Synthèse 420-KB1-LG
// Auteur: Samuel Leclerc Champagne
// Date: 
// 1 Affichage du fond, des murs et des points
// 2 Déplacement de Pac-Man sans foncer dans les murs
// 3 Ramassage des points par Pac-Man
// 4 Implémentation du téléporteur
// 5 Déplacement de Bashful et Pokey
// 6 Déplacement de Shadow et Speedy
// 7 Détection et affichage d'une partie gagnée
// 8 Détection et affichage d'une partie perdue
// 9 Débogage
// 10 Optionnellement: bonus
// 11 Écrire votre rapport

using System;
using System.Threading;
using System.IO;
using SFML.Graphics;
using SFML.Window;
using SFML.System;

namespace Pacman
{
    // ATTENTION! LE CODE CI-DESSOUS VOUS EST FOURNI ET NE DOIT PAS ÊTRE MODIFIÉ!
    // **************************************************************************

    // Énumération pour représenter une case du labyrinthe: Vide, Mur, Point, poWer pellet
    enum Objet { Mur, Point, Vide, Power };

    // Énumération pour représenter une direction
    enum Direction { Haut, Bas, Gauche, Droite };

    /// <summary>
    /// La classe Personnage sert à créer Pacman et les quatre fantômes
    /// </summary>
    class Personnage
    {
        /// <summary>
        /// Constructeur du personnage: pour créer un personnage, utilisez l'opérateur new
        /// </summary>
        /// <param name="fichierImage">Nom du fichier image</param>
        /// <param name="x">Position initiale en x</param>
        /// <param name="y">Position initiale en y</param>
        /// <param name="dir">Direction intiale</param>
        public Personnage(string fichierImage, int x, int y, Direction dir)
        {
            X = x;
            Y = y;
            Direction = dir;
            Texture = new Texture(fichierImage);

            TextureEnFuite = new Texture("images/peur.bmp");
            Sprite = new Sprite(Texture);
        }

        /// <summary>
        /// Utilisez la méthode Afficher du personnage pour afficher le personnage
        /// dans une fenêtre
        /// </summary>
        /// <param name="fenetre">Objet représentant la fenêtre</param>
        /// <param name="echelle">Facteur multiplicatif permettant de passer de la position
        /// dans le tableau 2D à la position dans l'image</param>
        public void Afficher(RenderWindow fenetre, int echelle)
        {
            Sprite.Position = new Vector2f(echelle * X, echelle * Y);
            fenetre.Draw(Sprite);
        }
        /// <value>
        /// Utilisez la propriété X afin de modifier la position horizontale
        /// </value>     
        public int X { get; set; }
        /// <value>
        /// Utilisez la propriété Y afin de modifier la position verticale
        /// </value>     
        public int Y { get; set; }
        /// <value>
        /// Utilisez la propriété Direction afin de conserver la direction du personnage
        /// </value>     
        public Direction Direction { get; set; }

        /// <value>
        /// Modifiez cette propriété pour indiquer qu'un fantome est en fuite (bonus suelement)
        /// </value>
        public bool EstEnFuite
        {
            get => estEnFuite;
            set => Sprite.Texture = new Texture((estEnFuite = value) ? TextureEnFuite : Texture);
        }
        #region
        private bool estEnFuite = false;
        private Texture Texture { get; set; }
        private Texture TextureEnFuite { get; set; }
        private Sprite Sprite { get; set; }
        #endregion
    }

    class Program
    {
        const int NbCaseLargeur = 19;
        const int NbCaseHauteur = 21;
        const int NbPixelsParCase = 16;
        const int NbPointsCarte = 151;

        static Objet[,] ChargerCarteJeu()
        {
            Objet[,] carte = new Objet[NbCaseHauteur, NbCaseLargeur];
            using (StreamReader reader = new StreamReader("Pac-Man carte.csv"))
            {
                for (int indiceLigne = 0; indiceLigne < NbCaseHauteur; indiceLigne++)
                {
                    string line = reader.ReadLine();
                    for (int indiceColonne = 0; indiceColonne < NbCaseLargeur; indiceColonne++)
                    {
                        string[] values = line.Split(',');
                        carte[indiceLigne, indiceColonne] = (Objet)int.Parse(values[indiceColonne]);
                    }
                }

            }
            return carte;
        }
        static void AfficherCarteJeu(Objet[,] carte, RenderWindow fenetre, Sprite Mur, Sprite Point)
        {
            for (int i = 0; i < carte.GetLength(0); i++)
            {
                for (int j = 0; j < carte.GetLength(1); j++)
                {
                    if (carte[i, j] == Objet.Mur)
                    {
                        Mur.Position = new Vector2f(j * NbPixelsParCase, i * NbPixelsParCase);
                        fenetre.Draw(Mur);
                    }
                    if (carte[i, j] == Objet.Point)
                    {
                        Point.Position = new Vector2f(j * NbPixelsParCase, i * NbPixelsParCase);
                        fenetre.Draw(Point);
                    }
                    //fenetre.Draw(carte[,j]);
                }
            }
        }
        static bool LimiterCarte(Objet[,] carte, Personnage Pacman)
        {
            bool MurBloquant = false;
            if (carte[Pacman.Y, Pacman.X] == Objet.Mur)
            {
                MurBloquant = true;
            }
            return MurBloquant;
        }
        static void Main(string[] args)
        {
            //DECL Input Output Var
            Objet[,] carte = ChargerCarteJeu(); // On charge la carte (fournie)
            VideoMode mode = new VideoMode(NbCaseLargeur * NbPixelsParCase, NbCaseHauteur * NbPixelsParCase);
            RenderWindow fenetre = new RenderWindow(mode, "Vecteur Nowelle");
            Texture Mur = new Texture("Images/mur.bmp");
            Sprite spriteMur = new Sprite(Mur);
            Sprite spritePoint = new Sprite(new Texture("Images/point.bmp"));
            Personnage Pacman = new Personnage("Images/pacman.bmp", 9, 15, Direction.Droite);
            //Sprite spritePacman = new Sprite(new Texture("Images/pacman.bmp"));
            //Sprite Point = new Sprite(new Texture("Images/point.bmp"));
            int compteur = 0;
            while (fenetre.IsOpen && !Keyboard.IsKeyPressed(Keyboard.Key.Escape))
                {
                    fenetre.DispatchEvents();
                    fenetre.Clear();
                    AfficherCarteJeu(carte, fenetre, spriteMur, spritePoint);
                    Pacman.Afficher(fenetre, NbPixelsParCase);
                    bool MurBloquant = LimiterCarte(carte, Pacman);
                    if (Keyboard.IsKeyPressed(Keyboard.Key.Up) && Pacman.Y > 0)
                    {
                        Pacman.Y--;
                    }
                    if (Keyboard.IsKeyPressed(Keyboard.Key.Down))
                    {
                        Pacman.Y++;
                    }
                    if (Keyboard.IsKeyPressed(Keyboard.Key.Left) && Pacman.Y > 0)
                    {
                        Pacman.X--;
                    }
                    if (Keyboard.IsKeyPressed(Keyboard.Key.Right))
                    {
                        Pacman.X++;
                    }
                //if (/*compteur*/ < NbPointsCarte)
                //{
                    if (carte[Pacman.Y, Pacman.X] == Objet.Point)
                    {
                        carte[Pacman.Y, Pacman.X] = Objet.Vide; 
                        //++compteur;
                        //AfficherCarteJeu(carte, fenetre, spriteMur, spritePoint);
                    }
                if (MurBloquant == true)
                {
                    Pacman = Pacman
                    //Pacman.Y--;
                    //Pacman.X++;
                    //Pacman
                    }
                fenetre.Display();
                    Thread.Sleep(40);
                }
                fenetre.Close();
                // **************************************************************************
                // Ajoutez votre code ci-dessous
            }
        }
    }
